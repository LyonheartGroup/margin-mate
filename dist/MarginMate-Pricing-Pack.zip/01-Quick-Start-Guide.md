# MarginMate Pricing Pack — Quick Start Guide

You bought this to do one thing better: price work like a professional instead of improvising and hoping the margin works out.

## What is in this pack

1. **Advanced Pricing Sheet**
   - Use this to model project pricing and compare scenarios.

2. **Retainer Pricing Planner**
   - Use this to price recurring work with cleaner monthly economics.

3. **Proposal Pricing Worksheet**
   - Use this before sending a quote to pressure-test whether the deal makes sense.

4. **Scope Creep Checklist**
   - Use this before kickoff and again before finalizing the proposal.

5. **Profitability Review Template**
   - Use this after the job to learn whether your estimate was honest or fantasy.

## Best workflow

### For project work
1. Start with the free MarginMate.ai calculator.
2. If the result is tight, open the **Proposal Pricing Worksheet**.
3. Refine the quote using the **Advanced Pricing Sheet**.
4. Protect yourself with the **Scope Creep Checklist**.
5. After delivery, review the result with the **Profitability Review Template**.

### For retainer work
1. Start with the **Retainer Pricing Planner**.
2. Estimate real monthly hours, delivery cost, and support burden.
3. Confirm your target margin.
4. Put overage rules in writing.

## The operating principle

**Revenue is vanity. Margin is survival.**

A project is not good because the invoice is large. A project is good because it pays well after time, revisions, software, and overhead are all accounted for.

## Recommended habit

Before every proposal, answer three questions:
- What does this deal actually cost to deliver?
- What is the minimum viable quote?
- If the client pushes, what will I cut: price, scope, or sanity?

Use the pack to answer those before the project answers them for you.
